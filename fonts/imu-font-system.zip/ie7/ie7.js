/* To avoid CSS expressions while still supporting IE 7 and IE 6, use this script */
/* The script tag referencing this file must be placed before the ending body tag. */

/* Use conditional comments in order to target IE 7 and older:
	<!--[if lt IE 8]><!-->
	<script src="ie7/ie7.js"></script>
	<!--<![endif]-->
*/

(function() {
	function addIcon(el, entity) {
		var html = el.innerHTML;
		el.innerHTML = '<span style="font-family: \'imu-font-system\'">' + entity + '</span>' + html;
	}
	var icons = {
		'icon-cross2': '&#xe117;',
		'icon-plus2': '&#xe114;',
		'icon-minus2': '&#xe115;',
		'icon-check': '&#xe116;',
		'icon-menu': '&#xe120;',
		'icon-repeat': '&#xe05a;',
		'icon-move': '&#xe118;',
		'icon-ban': '&#xe107;',
		'icon-clipboard': '&#xe008;',
		'icon-presentation': '&#xe00e;',
		'icon-wallet': '&#xe016;',
		'icon-gift': '&#xe017;',
		'icon-ribbon': '&#xe01e;',
		'icon-shield': '&#xe022;',
		'icon-map': '&#xe025;',
		'icon-basket': '&#xe027;',
		'icon-cloud': '&#xe04b;',
		'icon-global': '&#xe052;',
		'icon-scope': '&#xe058;',
		'icon-alarmclock': '&#xe059;',
		'icon-happy': '&#xe05b;',
		'icon-cloud2': '&#xe606;',
		'icon-pencil-neg': '&#xec50;',
		'icon-cancel-3': '&#xec34;',
		'icon-left-open-2': '&#xeb90;',
		'icon-right-open-2': '&#xeb92;',
		'icon-pencil-2': '&#xeb48;',
		'icon-play-circled-1': '&#xef4c;',
		'icon-pencil-6': '&#xeefb;',
		'icon-clock-5': '&#xed8b;',
		'icon-play-circled2-1': '&#xef4d;',
		'icon-upload-2': '&#xeb3d;',
		'icon-download-2': '&#xeb3b;',
		'icon-zoom-in-1': '&#xeb8b;',
		'icon-zoom-out-1': '&#xeb8d;',
		'icon-plus-2': '&#xeb1c;',
		'icon-minus-2': '&#xeb1e;',
		'icon-cancel-2': '&#xeb16;',
		'icon-ok-1': '&#xeb14;',
		'icon-lock-filled': '&#xeb2c;',
		'icon-lock-open-filled': '&#xeb2e;',
		'icon-uniF0DA': '&#xf0da;',
		'icon-uniF0DD': '&#xf0dd;',
		'icon-uniF107': '&#xf107;',
		'icon-uniF00C': '&#xf00c;',
		'icon-uniF077': '&#xf077;',
		'icon-uniF002': '&#xf002;',
		'icon-uniF005': '&#xf005;',
		'icon-uniF013': '&#xf013;',
		'icon-uniF019': '&#xf019;',
		'icon-uniF01D': '&#xf01d;',
		'icon-uniF02C': '&#xf02c;',
		'icon-uniF011': '&#xf011;',
		'icon-uniF081': '&#xf081;',
		'icon-uniF082': '&#xf082;',
		'icon-uniF084': '&#xf084;',
		'icon-uniF0B1': '&#xf0b1;',
		'icon-uniF0C7': '&#xf0c7;',
		'icon-uniF0C2': '&#xf0c2;',
		'icon-uniF0C0': '&#xf0c0;',
		'icon-uniF0D3': '&#xf0d3;',
		'icon-uniF0E0': '&#xf0e0;',
		'icon-uniF0D4': '&#xf0d4;',
		'icon-uniF1AD': '&#xf1ad;',
		'icon-uniF132': '&#xf132;',
		'icon-uniF144': '&#xf144;',
		'icon-uniF111': '&#xf111;',
		'icon-uniF10C': '&#xf10c;',
		'icon-earth': '&#xe607;',
		'icon-play': '&#xe600;',
		'icon-pause': '&#xe605;',
		'icon-search': '&#xe601;',
		'icon-zoomin': '&#xe602;',
		'icon-zoomout': '&#xe603;',
		'icon-clock': '&#xe604;',
		'icon-cross': '&#xe608;',
		'icon-minus': '&#xe609;',
		'icon-plus': '&#xe60a;',
		'0': 0
		},
		els = document.getElementsByTagName('*'),
		i, c, el;
	for (i = 0; ; i += 1) {
		el = els[i];
		if(!el) {
			break;
		}
		c = el.className;
		c = c.match(/icon-[^\s'"]+/);
		if (c && icons[c[0]]) {
			addIcon(el, icons[c[0]]);
		}
	}
}());
